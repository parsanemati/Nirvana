import scrapy

import re

class AmazonSpider(scrapy.Spider):
    name = "amazon_spider"
    global domain_name
    domain_name = "https://www.amazon.in"
    allowed_domains = ["amazon.in"]
    start_urls = (
        # airpods --> 1 product
        # "https://www.amazon.in/Apple-AirPods-with-Charging-Case/dp/B07Q6153FQ/ref=sr_1_1_sspa?keywords=airpods&qid=1573348906&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyMkVFTklLWk05S0syJmVuY3J5cHRlZElkPUEwNzc3Njc4MkVSVFE0Q0s4V0JLMCZlbmNyeXB0ZWRBZElkPUEwODUxNzkyMzRRWlBITE5XTTM5NyZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU=",
        # list of all products : page 1 url
        # "https://www.amazon.in/s?k=airpods&ref=nb_sb_noss",
        # all the urls
        "https://www.amazon.in/s?k=airpods&qid=1573351970&ref=sr_pg_1",
    )

    def parse(self,response):
        print("-------------------------------------")
        all_page_urls = response.xpath("//ul[@class='a-pagination']").extract_first()
        starting_index = all_page_urls.find("href=")
        res_url = all_page_urls[starting_index+5:]
        print(res_url)
        print(res_url.find("="))
        print(res_url[1:res_url.find("=")])
        res = res_url[1:res_url.find("=")]
        #print(res)
        for i in range(20):
            res_temp = "https://www.amazon.com"+res+"=airpods&amp;page="+str(i)
            yield scrapy.Request(res_temp, callback=self.one_page)


    def one_page(self,response):
        print("--------------ALL LINKS --------------")
        urls = response.xpath("//a[@class='a-link-normal a-text-normal']/@href").extract()
        print("Total number of urls : ",len(urls))
        for every_url in urls:
            every_url = "https://www.amazon.in/"+every_url
            yield scrapy.Request(every_url, callback=self.parse_page) 
        

    def parse_page(self,response):
        # print(response.text)
        # extracting title : HTML : id=productTitle
        print("----------------- PROJECT INFO -----------------------")
        produc_name = response.xpath("//span[@id='productTitle']/text()").extract()
        print("----------------- Product Name ---------------------")
        produc_name = produc_name[0]
        produc_name = re.sub(' +',' ',produc_name)
        produc_name = produc_name.replace("\n", '')
        produc_name = produc_name.strip()
        print(produc_name)
        print("----------------------------------------------------")


        print("----------------- Overall rating ---------------------")
        all_rating = response.xpath("//span[@class='a-icon-alt']/text()").extract_first()
        print(all_rating)
        print("----------------------------------------------------")

        print("----------------- Meta description ---------------------")
        description = response.xpath("//meta[@name='description']/@content").extract_first()
        print(description)
        print("----------------------------------------------------")

        print("----------------- Reviews ---------------------")
        revs = response.xpath("//div[@class='a-expander-content reviewText review-text-content a-expander-partial-collapse-content']//text()").extract()
        print(revs)
        print("----------------------------------------------------")

        
    